import { useState, useEffect } from 'react';

export type JournalAuthor = 'Mom' | 'Daughter';

export interface JournalEntry {
  id: string;
  text: string;
  author: JournalAuthor;
  createdAt: string;
}

const STORAGE_KEY = 'mommy_and_me_journal_entries';

export function useJournal() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Backfill author for old entries that didn't have it
        const migrated = parsed.map((e: JournalEntry) => ({ author: 'Mom' as JournalAuthor, ...e }));
        setEntries(migrated);
      }
    } catch {
      // ignore
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
      } catch {
        // ignore
      }
    }
  }, [entries, isLoaded]);

  const addEntry = (text: string, author: JournalAuthor = 'Mom') => {
    const newEntry: JournalEntry = {
      id: crypto.randomUUID(),
      text,
      author,
      createdAt: new Date().toISOString(),
    };
    setEntries(prev => [newEntry, ...prev]);
  };

  const clearEntries = () => setEntries([]);

  const deleteEntry = (id: string) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  };

  return { entries, isLoaded, addEntry, clearEntries, deleteEntry };
}
