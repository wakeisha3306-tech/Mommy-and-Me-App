import { useState, useEffect } from 'react';

export type NoteAuthor = 'Mom' | 'Daughter';

export interface Note {
  id: string;
  text: string;
  author: NoteAuthor;
  createdAt: string;
}

const STORAGE_KEY = 'mommy_and_me_shared_notes';

export function useNotes() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setNotes(JSON.parse(stored));
      }
    } catch {
      // ignore
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
      } catch {
        // ignore
      }
    }
  }, [notes, isLoaded]);

  const addNote = (text: string, author: NoteAuthor) => {
    const note: Note = {
      id: crypto.randomUUID(),
      text,
      author,
      createdAt: new Date().toISOString(),
    };
    setNotes(prev => [note, ...prev]);
  };

  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  return { notes, isLoaded, addNote, deleteNote };
}
