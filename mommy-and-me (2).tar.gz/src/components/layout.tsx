import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Home, Sparkles, BookHeart, MessageCircleHeart } from "lucide-react";
import { motion } from "framer-motion";

interface LayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
}

const NAV_ITEMS = [
  { href: "/", label: "Home", icon: Home },
  { href: "/affirmations", label: "Affirm", icon: Sparkles },
  { href: "/journal", label: "Journal", icon: BookHeart },
  { href: "/notes", label: "Notes", icon: MessageCircleHeart },
];

export function Layout({ children, title, subtitle }: LayoutProps) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen w-full flex flex-col items-center bg-background relative overflow-hidden">
      {/* Background blobs */}
      <div className="pointer-events-none fixed top-[-15%] left-[-15%] w-[50%] h-[50%] rounded-full bg-primary/8 blur-[120px]" />
      <div className="pointer-events-none fixed bottom-[-10%] right-[-10%] w-[45%] h-[45%] rounded-full bg-accent/10 blur-[100px]" />

      {/* Header */}
      {(title) && (
        <header className="w-full max-w-lg px-6 pt-10 pb-2 z-10 relative">
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl font-serif text-foreground">{title}</h1>
            {subtitle && (
              <p className="text-sm text-muted-foreground mt-1 font-sans">{subtitle}</p>
            )}
          </motion.div>
        </header>
      )}

      {/* Page Content */}
      <main className="flex-1 w-full max-w-lg px-6 pt-4 pb-28 z-10 relative flex flex-col">
        {children}
      </main>

      {/* Bottom Tab Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 flex justify-center pointer-events-none">
        <div className="w-full max-w-lg px-4 pb-5 pointer-events-auto">
          <div className="flex items-center justify-around bg-white/90 backdrop-blur-md border border-border rounded-[2rem] shadow-lg px-2 py-3">
            {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
              const isActive = location === href;
              return (
                <Link
                  key={href}
                  href={href}
                  className="flex flex-col items-center gap-1 px-5 py-1.5 rounded-2xl transition-all duration-200 group"
                >
                  <div className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all duration-200 ${
                    isActive
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground group-hover:text-primary group-hover:bg-primary/8"
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-medium tracking-wide transition-colors duration-200 ${
                    isActive ? "text-primary" : "text-muted-foreground"
                  }`}>
                    {label}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}
