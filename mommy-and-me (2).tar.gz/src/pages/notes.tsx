import { useState } from "react";
import { Layout } from "@/components/layout";
import { useNotes, NoteAuthor } from "@/hooks/use-notes";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { Send, Trash2, MessageCircleHeart, Flower } from "lucide-react";

const AUTHOR_CONFIG: Record<NoteAuthor, { emoji: string; bgCard: string; badge: string; nameBg: string }> = {
  Mom: {
    emoji: "👩🏾",
    bgCard: "bg-primary/8 border-primary/15",
    badge: "bg-primary/15 text-primary",
    nameBg: "from-primary/20 to-primary/5",
  },
  Daughter: {
    emoji: "👧🏾",
    bgCard: "bg-accent/10 border-accent/15",
    badge: "bg-accent/20 text-accent-foreground",
    nameBg: "from-accent/20 to-accent/5",
  },
};

const QUICK_NOTES = [
  "I love you so much 💕",
  "You make me so proud 🌟",
  "Thank you for being you 🌸",
  "I'm always here for you 🤗",
  "You are doing amazing 💪🏽",
  "I was thinking of you 💭",
];

export default function Notes() {
  const { notes, isLoaded, addNote, deleteNote } = useNotes();
  const [text, setText] = useState("");
  const [author, setAuthor] = useState<NoteAuthor>("Mom");

  const handleSend = () => {
    if (!text.trim()) return;
    addNote(text.trim(), author);
    setText("");
  };

  if (!isLoaded) return null;

  return (
    <Layout title="Our Notes" subtitle="Little messages between us, always">
      <div className="flex flex-col gap-6 mt-2">

        {/* Write a Note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[1.5rem] shadow-sm border border-border overflow-hidden"
        >
          {/* Who is writing? */}
          <div className="flex border-b border-border">
            {(["Mom", "Daughter"] as NoteAuthor[]).map((a) => (
              <button
                key={a}
                onClick={() => setAuthor(a)}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 text-sm font-semibold transition-all duration-200 ${
                  author === a
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted/50"
                }`}
              >
                <span>{AUTHOR_CONFIG[a].emoji}</span>
                {a}'s Note
              </button>
            ))}
          </div>

          <div className="p-5">
            <p className="text-xs text-muted-foreground mb-3">Quick picks:</p>
            <div className="flex flex-wrap gap-2 mb-4">
              {QUICK_NOTES.map((q) => (
                <button
                  key={q}
                  onClick={() => setText(q)}
                  className="text-xs px-3 py-1.5 rounded-full bg-muted/60 text-muted-foreground border border-transparent hover:border-border hover:bg-muted transition-all duration-200"
                >
                  {q}
                </button>
              ))}
            </div>

            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={author === "Mom" ? "Leave a little love note for your daughter..." : "Leave a little love note for Mom..."}
              className="w-full min-h-[100px] bg-muted/30 rounded-2xl p-4 resize-none border-none focus:outline-none focus:ring-2 focus:ring-primary/20 text-foreground placeholder:text-muted-foreground text-base transition-shadow"
            />

            <div className="flex justify-end mt-4">
              <button
                onClick={handleSend}
                disabled={!text.trim()}
                className="flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground rounded-2xl font-semibold text-sm shadow-sm hover:shadow-md hover:-translate-y-0.5 disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200"
              >
                <Send className="w-4 h-4" />
                Send Note
              </button>
            </div>
          </div>
        </motion.div>

        {/* Notes Thread */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3 px-1">
            Our Conversation
          </p>

          {notes.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-14 text-center gap-3"
            >
              <MessageCircleHeart className="w-8 h-8 text-muted-foreground/40" />
              <p className="text-muted-foreground font-serif italic text-lg">
                No notes yet.
              </p>
              <p className="text-xs text-muted-foreground/60">Leave the first one above — she'll love it.</p>
            </motion.div>
          ) : (
            <div className="flex flex-col gap-3">
              <AnimatePresence>
                {notes.map((note) => {
                  const cfg = AUTHOR_CONFIG[note.author];
                  const isMom = note.author === "Mom";
                  return (
                    <motion.div
                      key={note.id}
                      initial={{ opacity: 0, x: isMom ? -16 : 16 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.25 }}
                      className={`flex ${isMom ? "justify-start" : "justify-end"}`}
                    >
                      <div className={`max-w-[82%] group`}>
                        <div className={`relative rounded-2xl border p-4 shadow-sm ${cfg.bgCard} ${isMom ? "rounded-tl-sm" : "rounded-tr-sm"}`}>
                          <p className="text-foreground text-sm leading-relaxed">{note.text}</p>
                          <button
                            onClick={() => deleteNote(note.id)}
                            className="absolute -top-2 -right-2 w-6 h-6 flex items-center justify-center rounded-full bg-white border border-border shadow-sm opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all duration-200"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                        <div className={`flex items-center gap-1.5 mt-1.5 ${isMom ? "justify-start" : "justify-end"}`}>
                          <span className="text-xs text-muted-foreground/70">
                            {cfg.emoji} {note.author} · {format(new Date(note.createdAt), "MMM d 'at' h:mm a")}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              <div className="flex items-center justify-center py-2 gap-2">
                <Flower className="w-3.5 h-3.5 text-muted-foreground/40" />
                <span className="text-xs text-muted-foreground/50 italic">{notes.length} note{notes.length !== 1 ? "s" : ""} shared</span>
                <Flower className="w-3.5 h-3.5 text-muted-foreground/40" />
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
