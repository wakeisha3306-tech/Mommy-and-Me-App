import { useState, useCallback } from "react";
import { Layout } from "@/components/layout";
import { motion, AnimatePresence } from "framer-motion";
import { RefreshCcw, ChevronLeft, ChevronRight } from "lucide-react";

const AFFIRMATIONS = [
  { text: "I am strong and capable", emoji: "💪🏽" },
  { text: "I am loved and appreciated", emoji: "💕" },
  { text: "I can get through anything", emoji: "🌸" },
  { text: "My voice matters", emoji: "🗣️" },
  { text: "I am growing every day", emoji: "🌱" },
  { text: "I am enough, exactly as I am", emoji: "✨" },
  { text: "My love creates a safe place", emoji: "🏡" },
  { text: "I deserve peace and rest", emoji: "🌙" },
  { text: "I lead with grace and strength", emoji: "👑" },
  { text: "I am worthy of good things", emoji: "🌟" },
];

export default function Affirmations() {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);

  const next = useCallback(() => {
    setDirection(1);
    setIndex((prev) => (prev + 1) % AFFIRMATIONS.length);
  }, []);

  const prev = useCallback(() => {
    setDirection(-1);
    setIndex((prev) => (prev - 1 + AFFIRMATIONS.length) % AFFIRMATIONS.length);
  }, []);

  const shuffle = useCallback(() => {
    setDirection(1);
    setIndex((prev) => {
      let next = Math.floor(Math.random() * AFFIRMATIONS.length);
      while (next === prev) next = Math.floor(Math.random() * AFFIRMATIONS.length);
      return next;
    });
  }, []);

  const current = AFFIRMATIONS[index];

  return (
    <Layout title="Affirmations" subtitle="Words to carry you through the day">

      {/* Main Card */}
      <div className="flex-1 flex flex-col gap-8 mt-4">
        <div className="relative h-72 flex items-center justify-center perspective-[1000px]">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={index}
              custom={direction}
              initial={{ opacity: 0, x: direction * 60, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: direction * -60, scale: 0.95 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="absolute inset-0 bg-white rounded-[2rem] p-8 shadow-md border border-border flex flex-col items-center justify-center text-center gap-4 overflow-hidden"
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary/40 via-accent/60 to-primary/40 rounded-t-[2rem]" />
              <span className="text-6xl">{current.emoji}</span>
              <p className="text-2xl font-serif text-foreground leading-snug">
                "{current.text}"
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                {index + 1} of {AFFIRMATIONS.length}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Dot Indicators */}
        <div className="flex justify-center gap-2">
          {AFFIRMATIONS.map((_, i) => (
            <button
              key={i}
              onClick={() => { setDirection(i > index ? 1 : -1); setIndex(i); }}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === index ? "w-6 bg-primary" : "w-2 bg-muted-foreground/30"
              }`}
            />
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between gap-4">
          <button
            onClick={prev}
            className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white border border-border shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 text-muted-foreground hover:text-foreground"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={shuffle}
            className="flex-1 flex items-center justify-center gap-2 h-14 rounded-[2rem] bg-primary text-primary-foreground font-semibold text-base shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
          >
            <RefreshCcw className="w-5 h-5" />
            Shuffle
          </button>

          <button
            onClick={next}
            className="w-14 h-14 flex items-center justify-center rounded-2xl bg-white border border-border shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 text-muted-foreground hover:text-foreground"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* All Affirmations List */}
        <div className="mt-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3 px-1">All Affirmations</p>
          <div className="flex flex-col gap-2">
            {AFFIRMATIONS.map((aff, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                onClick={() => { setDirection(i > index ? 1 : -1); setIndex(i); }}
                className={`flex items-center gap-3 p-4 rounded-2xl text-left transition-all duration-200 border ${
                  i === index
                    ? "bg-primary/10 border-primary/30 shadow-sm"
                    : "bg-white border-border hover:bg-muted/50 hover:border-border"
                }`}
              >
                <span className="text-2xl">{aff.emoji}</span>
                <span className={`text-sm font-medium ${i === index ? "text-primary" : "text-foreground"}`}>
                  {aff.text}
                </span>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
