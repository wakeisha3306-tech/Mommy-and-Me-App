import { useState } from "react";
import { Layout } from "@/components/layout";
import { useJournal } from "@/hooks/use-journal";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { PenLine, Trash2, Heart, Flower } from "lucide-react";

type Author = "Mom" | "Daughter";

const AUTHOR_CONFIG: Record<Author, { emoji: string; color: string; dot: string; badge: string }> = {
  Mom: {
    emoji: "👩🏾",
    color: "bg-primary/10 text-primary border-primary/20",
    dot: "bg-primary",
    badge: "bg-primary/15 text-primary",
  },
  Daughter: {
    emoji: "👧🏾",
    color: "bg-accent/15 text-accent-foreground border-accent/20",
    dot: "bg-accent",
    badge: "bg-accent/20 text-accent-foreground",
  },
};

const MOODS = [
  { label: "Grateful", emoji: "🙏🏽" },
  { label: "Happy", emoji: "😊" },
  { label: "Reflective", emoji: "💭" },
  { label: "Strong", emoji: "💪🏽" },
  { label: "Tired", emoji: "🌙" },
  { label: "Loved", emoji: "💕" },
];

export default function Journal() {
  const { entries, addEntry, deleteEntry, isLoaded } = useJournal();
  const [newEntry, setNewEntry] = useState("");
  const [author, setAuthor] = useState<Author>("Mom");
  const [mood, setMood] = useState<string | null>(null);

  const handleSave = () => {
    if (!newEntry.trim()) return;
    const text = mood ? `${mood} · ${newEntry.trim()}` : newEntry.trim();
    addEntry(text, author);
    setNewEntry("");
    setMood(null);
  };

  if (!isLoaded) return null;

  return (
    <Layout title="Journal" subtitle="Your private space to feel, reflect, and grow">
      <div className="flex flex-col gap-6 mt-2">

        {/* Write Box */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[1.5rem] shadow-sm border border-border overflow-hidden"
        >
          {/* Author selector */}
          <div className="flex border-b border-border">
            {(["Mom", "Daughter"] as Author[]).map((a) => (
              <button
                key={a}
                onClick={() => setAuthor(a)}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 text-sm font-semibold transition-all duration-200 ${
                  author === a
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted/50"
                }`}
              >
                <span>{AUTHOR_CONFIG[a].emoji}</span>
                {a}
              </button>
            ))}
          </div>

          <div className="p-5">
            {/* Mood picker */}
            <div className="flex flex-wrap gap-2 mb-4">
              {MOODS.map((m) => (
                <button
                  key={m.label}
                  onClick={() => setMood(mood === `${m.emoji} ${m.label}` ? null : `${m.emoji} ${m.label}`)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200 ${
                    mood === `${m.emoji} ${m.label}`
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-muted/60 text-muted-foreground border-transparent hover:border-border"
                  }`}
                >
                  {m.emoji} {m.label}
                </button>
              ))}
            </div>

            <textarea
              value={newEntry}
              onChange={(e) => setNewEntry(e.target.value)}
              placeholder="What's on your heart today?"
              className="w-full min-h-[120px] bg-muted/30 rounded-2xl p-4 resize-none border-none focus:outline-none focus:ring-2 focus:ring-primary/20 text-foreground placeholder:text-muted-foreground text-base transition-shadow"
            />

            <div className="flex justify-between items-center mt-4">
              <div className="flex items-center gap-1.5">
                <PenLine className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{entries.length} {entries.length === 1 ? "entry" : "entries"}</span>
              </div>
              <button
                onClick={handleSave}
                disabled={!newEntry.trim()}
                className="flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground rounded-2xl font-semibold text-sm shadow-sm hover:shadow-md hover:-translate-y-0.5 disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200"
              >
                <Heart className="w-4 h-4" />
                Save
              </button>
            </div>
          </div>
        </motion.div>

        {/* Past Entries */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3 px-1">Past Entries</p>

          {entries.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-14 text-center gap-3"
            >
              <Flower className="w-8 h-8 text-muted-foreground/40" />
              <p className="text-muted-foreground font-serif italic text-lg">
                Your story starts here.
              </p>
              <p className="text-xs text-muted-foreground/60">Write your first entry above.</p>
            </motion.div>
          ) : (
            <div className="flex flex-col gap-3">
              <AnimatePresence>
                {entries.map((entry) => {
                  const entryAuthor = (entry.author as Author) || "Mom";
                  const cfg = AUTHOR_CONFIG[entryAuthor] || AUTHOR_CONFIG.Mom;
                  return (
                    <motion.div
                      key={entry.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.96 }}
                      transition={{ duration: 0.25 }}
                      className="bg-white border border-border rounded-2xl p-5 shadow-sm group"
                    >
                      <div className="flex items-center justify-between mb-2.5">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.badge}`}>
                            {AUTHOR_CONFIG[entryAuthor].emoji} {entryAuthor}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(entry.createdAt), "MMM d, yyyy")}
                          </span>
                        </div>
                        <button
                          onClick={() => deleteEntry(entry.id)}
                          className="opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-destructive rounded-xl hover:bg-destructive/10 transition-all duration-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-foreground leading-relaxed text-sm whitespace-pre-wrap">
                        {entry.text}
                      </p>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
